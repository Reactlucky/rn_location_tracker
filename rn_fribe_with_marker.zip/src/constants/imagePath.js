export default {
    primaryMarker: require('../assets/images/driver_mark.png'),
    secondaryMarker: require("../assets/images/orange_mark.png"),
    logo: require("../assets/images/logo.png"),
    greenIndicator: require("../assets/images/greenIndicator.png"),

}