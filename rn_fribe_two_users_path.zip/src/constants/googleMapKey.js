export const GOOGLE_MAP_KEY = "AIzaSyB0CuIuyfZ8aWqS7pasx4vbd8cEizcV294"
